<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Users extends BaseController
{
    public function index()
    {
        echo 'saya Admin';
    }

    public function about()
    {
        echo 'nama saya choly';
    }

    //--------------------------------------------------------------------

}
