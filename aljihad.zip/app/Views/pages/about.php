    <?= $this->extend('layout/template'); ?>

    <?= $this->section('content'); ?>

    <!-- <section class="profil">
        <div class="intro-text">
            <div class="intro-lead-in">Profil</div>
            <div class="intro-heading ">Yayasan Al-Jihad Surabaya</div>
        </div>
    </section> -->

    <img src="/img/slider/1.jpg" class="img-fluid" alt="Responsive image" style="width: 100%; height:400px;">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>About Me</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis quis excepturi rerum, porro facere dignissimos expedita minus magnam officia delectus assumenda perferendis, alias dolore velit tempore unde ipsum. Exercitationem, corrupti!</p>
            </div>
        </div>
    </div>
    <?= $this->endSection(); ?>